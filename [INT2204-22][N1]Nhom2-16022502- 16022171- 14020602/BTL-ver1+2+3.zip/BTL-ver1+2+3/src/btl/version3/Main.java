/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btl.version3;


//import btl.version2.*;
import java.io.IOException;

/**
 *
 * @author QUANG
 */
public class Main extends DictionaryCommandline{
    
    public static void main(String[] args) throws IOException {
        DictionaryCommandline dicCom = new DictionaryCommandline();
        dicCom.dictionarybasic();
        
    }
}
