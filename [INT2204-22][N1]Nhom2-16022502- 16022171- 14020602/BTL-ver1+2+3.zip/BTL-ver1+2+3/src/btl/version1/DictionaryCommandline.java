/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package btl.version1;
import btl.version1.Dictionary;
/**
 *
 * @author QUANG
 */
public class DictionaryCommandline extends DictionaryManagement{
    public void dictionarybasic(){
        insertFromCommandline();
        showAllWords();  
    }
}
